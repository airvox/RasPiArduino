#!/bin/bash

mv /tmp/sketch.hex /tmp/sketch.bin
chmod 06755 /tmp/sketch.bin
